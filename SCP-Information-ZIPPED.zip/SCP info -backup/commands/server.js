module.exports = {
	name: 'server',
    cooldown: 5,
    description: 'Gives server description.',
	execute(message, args) {
		message.channel.send(`Server name: ${message.guild.name}\nTotal members: ${message.guild.memberCount}`);
	},
};