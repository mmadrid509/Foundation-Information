module.exports = {
	name: 'user-info',
    cooldown: 5,
    description: 'Give author information on a user.',
	execute(message, args) {
		message.channel.send(`Your username: ${message.author.username}\nYour ID: ${message.author.id}`);
	},
};